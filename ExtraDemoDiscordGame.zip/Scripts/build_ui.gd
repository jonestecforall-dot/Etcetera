extends CanvasLayer

# ==========================================
# SIGNALS
# ==========================================
signal tile_selected(index: int)
signal tool_changed(tool: int)
signal undo_pressed
signal save_pressed
signal delete_all_pressed  # <--- NEW SIGNAL
signal joystick_dragged(offset: Vector2)
signal joystick_released
signal last_position_updated(position: Vector2)  # <--- NEW SIGNAL for position updates

# ==========================================
# UI ELEMENTS
# ==========================================
var tile_buttons: Array[Button] = []
var selected_tile_index: int = 0
var current_tool: int = 0
var main_container: VBoxContainer
var tile_grid: GridContainer
var last_position_label: Label  # <--- NEW: Label for last position

# Joystick variables
var joystick_base: ColorRect
var joystick_knob: ColorRect
var joystick_center: Vector2 = Vector2.ZERO
var joystick_active: bool = false
var joystick_radius: float = 50.0
var joystick_container: Control

# ==========================================
# INITIALIZATION
# ==========================================
func _ready() -> void:
	_build_ui_elements()
	_build_joystick()

# ==========================================
# BUILD UI
# ==========================================
func _build_ui_elements() -> void:
	# Create a Control node to hold everything
	var ui_root = Control.new()
	ui_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(ui_root)
	
	# Main container
	main_container = VBoxContainer.new()
	main_container.set_anchors_preset(Control.PRESET_FULL_RECT)
	main_container.add_theme_constant_override("separation", 10)
	ui_root.add_child(main_container)
	
	# Title
	var title = Label.new()
	title.text = "MAP EDITOR"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 24)
	main_container.add_child(title)
	
	# Tool buttons row
	var tool_row = HBoxContainer.new()
	tool_row.add_theme_constant_override("separation", 5)
	main_container.add_child(tool_row)
	
	var place_btn = Button.new()
	place_btn.text = "PLACE"
	place_btn.pressed.connect(func(): _on_tool_button_pressed(0))
	tool_row.add_child(place_btn)
	
	var delete_btn = Button.new()
	delete_btn.text = "DELETE"
	delete_btn.pressed.connect(func(): _on_tool_button_pressed(1))
	tool_row.add_child(delete_btn)
	
	var paint_delete_btn = Button.new()
	paint_delete_btn.text = "PAINT DEL"
	paint_delete_btn.pressed.connect(func(): _on_tool_button_pressed(2))
	tool_row.add_child(paint_delete_btn)
	
	# Action buttons row
	var action_row = HBoxContainer.new()
	action_row.add_theme_constant_override("separation", 10)
	main_container.add_child(action_row)
	
	var undo_btn = Button.new()
	undo_btn.text = "UNDO"
	undo_btn.pressed.connect(func(): undo_pressed.emit())
	action_row.add_child(undo_btn)
	
	var delete_all_btn = Button.new()  # <--- NEW: Delete All button
	delete_all_btn.text = "DELETE ALL"
	delete_all_btn.modulate = Color(1, 0.3, 0.3, 1)  # Red tint for danger
	delete_all_btn.pressed.connect(func(): delete_all_pressed.emit())
	action_row.add_child(delete_all_btn)
	
	var save_btn = Button.new()
	save_btn.text = "SAVE"
	save_btn.pressed.connect(func(): save_pressed.emit())
	action_row.add_child(save_btn)
	
	# Last Position Info  <--- NEW: Position counter section
	var info_container = HBoxContainer.new()
	info_container.add_theme_constant_override("separation", 10)
	main_container.add_child(info_container)
	
	var position_label_prefix = Label.new()
	position_label_prefix.text = "LAST POSITION:"
	position_label_prefix.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	position_label_prefix.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info_container.add_child(position_label_prefix)
	
	last_position_label = Label.new()
	last_position_label.text = "NONE"
	last_position_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	last_position_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	last_position_label.add_theme_color_override("font_color", Color(0.3, 1, 0.3, 1))
	info_container.add_child(last_position_label)
	
	# Tile selection scroll area
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	main_container.add_child(scroll)
	
	tile_grid = GridContainer.new()
	tile_grid.columns = 4
	tile_grid.add_theme_constant_override("h_separation", 5)
	tile_grid.add_theme_constant_override("v_separation", 5)
	scroll.add_child(tile_grid)

# ==========================================
# UPDATE LAST POSITION
# ==========================================
func update_last_position(position: Vector2) -> void:
	if last_position_label:
		last_position_label.text = "X: %d, Y: %d" % [position.x, position.y]
		last_position_updated.emit(position)

func clear_last_position() -> void:
	if last_position_label:
		last_position_label.text = "NONE"
		last_position_label.add_theme_color_override("font_color", Color(0.3, 1, 0.3, 1))

# ==========================================
# BUILD JOYSTICK
# ==========================================
func _build_joystick() -> void:
	# Get viewport size for positioning
	var viewport_size = get_viewport().get_visible_rect().size
	
	# Create joystick container (for positioning and input)
	joystick_container = Control.new()
	joystick_container.position = viewport_size - Vector2(150, 150)
	joystick_container.size = Vector2(120, 120)
	joystick_container.mouse_filter = Control.MOUSE_FILTER_STOP
	joystick_container.gui_input.connect(_on_joystick_gui_input)
	add_child(joystick_container)
	
	# Create base (simple rectangle)
	joystick_base = ColorRect.new()
	joystick_base.color = Color(0.2, 0.2, 0.2, 0.6)
	joystick_base.size = Vector2(120, 120)
	joystick_base.position = Vector2.ZERO
	joystick_base.mouse_filter = Control.MOUSE_FILTER_IGNORE
	joystick_container.add_child(joystick_base)
	
	# Set center
	joystick_center = Vector2(60, 60)
	
	# Create knob (simple rectangle)
	joystick_knob = ColorRect.new()
	joystick_knob.color = Color(0.4, 0.7, 1.0, 0.9)
	joystick_knob.size = Vector2(50, 50)
	joystick_knob.position = joystick_center - Vector2(25, 25)
	joystick_knob.mouse_filter = Control.MOUSE_FILTER_IGNORE
	joystick_container.add_child(joystick_knob)

# ==========================================
# JOYSTICK INPUT HANDLING
# ==========================================
func _on_joystick_gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var local_pos = event.position
		if local_pos.distance_to(joystick_center) < joystick_radius:
			if event.pressed:
				joystick_active = true
				_update_joystick_knob(local_pos)
			else:
				joystick_active = false
				_reset_joystick()
				joystick_released.emit()
				
	elif event is InputEventMouseMotion:
		if joystick_active:
			_update_joystick_knob(event.position)

func _update_joystick_knob(local_pos: Vector2) -> void:
	var offset_vec = local_pos - joystick_center
	var max_offset = joystick_radius - 25.0
	
	if offset_vec.length() > max_offset:
		offset_vec = offset_vec.normalized() * max_offset
	
	joystick_knob.position = joystick_center + offset_vec - Vector2(25, 25)
	
	# Emit signal with normalized offset
	var normalized_offset = offset_vec / max_offset
	joystick_dragged.emit(normalized_offset)

func _reset_joystick() -> void:
	joystick_knob.position = joystick_center - Vector2(25, 25)

# ==========================================
# TOOL HANDLING
# ==========================================
func _on_tool_button_pressed(tool: int) -> void:
	current_tool = tool
	tool_changed.emit(tool)
	update_tool_info(tool)

# ==========================================
# TILE HANDLING
# ==========================================
func update_tile_info(tile_names: Array[String], selected_index: int) -> void:
	selected_tile_index = selected_index
	
	# Clear existing buttons
	for child in tile_grid.get_children():
		child.queue_free()
	
	tile_buttons.clear()
	
	# Create buttons for each tile
	for i in range(tile_names.size()):
		var btn = Button.new()
		btn.text = tile_names[i]
		btn.custom_minimum_size = Vector2(80, 80)
		btn.pressed.connect(_on_tile_button_pressed.bind(i))
		tile_grid.add_child(btn)
		tile_buttons.append(btn)
	
	update_tile_selection()

func _on_tile_button_pressed(index: int) -> void:
	selected_tile_index = index
	tile_selected.emit(index)
	update_tile_selection()

func update_tile_selection() -> void:
	for i in range(tile_buttons.size()):
		if i == selected_tile_index:
			tile_buttons[i].modulate = Color(1, 1, 0.5, 1)
		else:
			tile_buttons[i].modulate = Color(1, 1, 1, 1)

# ==========================================
# TOOL INFO UPDATE
# ==========================================
func update_tool_info(current_tool: int) -> void:
	# Update tool button states if needed
	pass
