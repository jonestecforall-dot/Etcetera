extends CanvasLayer

# --- Signals to send to the Player ---
signal ui_move_direction(direction: Vector2)
signal ui_attack_pressed
signal ui_jump_pressed  # Changed from ui_dodge_pressed
signal ui_rage_pressed

# --- Screen Size Detection ---
var screen_size : Vector2

# --- Joystick Variables ---
var joystick_base : Panel
var joystick_handle : Panel
var is_touching_joystick : bool = false
var joystick_touch_index : int = -1
var joystick_center : Vector2
var joystick_radius : float = 80.0

func _ready() -> void:
	# Get the actual viewport size (works on mobile and desktop)
	screen_size = get_viewport().get_visible_rect().size
	_build_joystick()
	_build_action_buttons()

# --- Build the Left Joystick ---
func _build_joystick() -> void:
	# The joystick base (big circle)
	joystick_base = Panel.new()
	joystick_base.custom_minimum_size = Vector2(joystick_radius * 2, joystick_radius * 2)
	joystick_base.position = Vector2(50, screen_size.y - (joystick_radius * 2) - 50)
	joystick_base.mouse_filter = Control.MOUSE_FILTER_STOP
	joystick_base.gui_input.connect(_on_joystick_gui_input)
	add_child(joystick_base)
	
	# Draw a visual circle for the base
	var base_style = StyleBoxFlat.new()
	base_style.bg_color = Color(1, 1, 1, 0.2)
	base_style.set_corner_radius_all(joystick_radius)
	joystick_base.add_theme_stylebox_override("panel", base_style)
	
	# The joystick handle (smaller circle)
	joystick_handle = Panel.new()
	joystick_handle.custom_minimum_size = Vector2(60, 60)
	joystick_handle.position = Vector2(joystick_radius - 30, joystick_radius - 30)
	joystick_handle.mouse_filter = Control.MOUSE_FILTER_IGNORE
	joystick_base.add_child(joystick_handle)
	
	var handle_style = StyleBoxFlat.new()
	handle_style.bg_color = Color(1, 1, 1, 0.6)
	handle_style.set_corner_radius_all(30)
	joystick_handle.add_theme_stylebox_override("panel", handle_style)

# --- Build the Right Action Buttons ---
func _build_action_buttons() -> void:
	var button_size = Vector2(80, 80)
	var spacing = 100.0
	var start_x = screen_size.x - 100
	var start_y = screen_size.y - 250

	# ATTACK Button (Big Red)
	var attack_btn = Button.new()
	attack_btn.text = "ATK"
	attack_btn.custom_minimum_size = button_size
	attack_btn.position = Vector2(start_x, start_y + spacing)
	attack_btn.pressed.connect(func(): ui_attack_pressed.emit())
	add_child(attack_btn)

	# JUMP Button (Green - Changed from DODGE)
	var jump_btn = Button.new()
	jump_btn.text = "JMP"
	jump_btn.custom_minimum_size = button_size
	jump_btn.position = Vector2(start_x - spacing, start_y + (spacing * 1.5))
	jump_btn.pressed.connect(func(): ui_jump_pressed.emit())
	add_child(jump_btn)

	# RAGE Button (Yellow)
	var rage_btn = Button.new()
	rage_btn.text = "RGE"
	rage_btn.custom_minimum_size = button_size
	rage_btn.position = Vector2(start_x, start_y + (spacing * 2))
	rage_btn.pressed.connect(func(): ui_rage_pressed.emit())
	add_child(rage_btn)

# --- Input Handling (Directly on the Joystick Base) ---
func _on_joystick_gui_input(event: InputEvent) -> void:
	# This only fires when touching/clicking the joystick base
	if event is InputEventScreenTouch:
		if event.pressed and not is_touching_joystick:
			is_touching_joystick = true
			joystick_touch_index = event.index
			joystick_center = joystick_base.size / 2.0
			
			# Update handle position immediately
			_update_joystick_handle(event.position)
			
		elif not event.pressed and event.index == joystick_touch_index:
			# Release
			is_touching_joystick = false
			joystick_touch_index = -1
			joystick_handle.position = Vector2(joystick_radius - 30, joystick_radius - 30)
			ui_move_direction.emit(Vector2.ZERO)

	elif event is InputEventScreenDrag and event.index == joystick_touch_index:
		_update_joystick_handle(event.position)
		
	# Support for desktop mouse testing
	elif event is InputEventMouseButton:
		if event.pressed:
			is_touching_joystick = true
			joystick_center = joystick_base.size / 2.0
			_update_joystick_handle(event.position)
		else:
			is_touching_joystick = false
			joystick_handle.position = Vector2(joystick_radius - 30, joystick_radius - 30)
			ui_move_direction.emit(Vector2.ZERO)
			
	elif event is InputEventMouseMotion and is_touching_joystick:
		_update_joystick_handle(event.position)

# --- Calculate and Clamp the Joystick Handle ---
func _update_joystick_handle(touch_pos: Vector2) -> void:
	# NOTE: touch_pos is now LOCAL to the joystick base
	var delta = touch_pos - joystick_center
	var clamped_delta = delta.limit_length(joystick_radius)
	joystick_handle.position = Vector2(joystick_radius - 30, joystick_radius - 30) + clamped_delta
	
	# Normalize to get the direction
	var direction = clamped_delta / joystick_radius
	ui_move_direction.emit(direction)
